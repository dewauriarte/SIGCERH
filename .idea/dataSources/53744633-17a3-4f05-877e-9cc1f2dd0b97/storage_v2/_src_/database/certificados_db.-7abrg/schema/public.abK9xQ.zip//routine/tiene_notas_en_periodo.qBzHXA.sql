create function tiene_notas_en_periodo(p_estudiante_id uuid, p_anio integer, p_grado_numero integer) returns boolean
    language plpgsql
as
$$
BEGIN
    RETURN EXISTS(
        SELECT 1
        FROM actaestudiante ae
        INNER JOIN actafisica af ON ae.acta_id = af.id
        INNER JOIN aniolectivo al ON af.aniolectivo_id = al.id
        INNER JOIN grado g ON af.grado_id = g.id
        WHERE ae.estudiante_id = p_estudiante_id
          AND al.anio = p_anio
          AND g.numero = p_grado_numero
          AND EXISTS(
              SELECT 1 FROM actanota an
              WHERE an.acta_estudiante_id = ae.id
          )
    );
END;
$$;

alter function tiene_notas_en_periodo(uuid, integer, integer) owner to postgres;

