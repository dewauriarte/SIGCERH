create function calcular_monto_neto_pago() returns trigger
    language plpgsql
as
$$
BEGIN
    IF NEW.comision IS NOT NULL AND NEW.comision > 0 THEN
        NEW.montoNeto := NEW.monto - NEW.comision;
    ELSE
        NEW.montoNeto := NEW.monto;
    END IF;
    
    RETURN NEW;
END;
$$;

alter function calcular_monto_neto_pago() owner to postgres;

