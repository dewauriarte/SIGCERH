create view v_actas_estudiante
            (estudiante_id, dni, nombres, apellidopaterno, apellidomaterno, nombrecompleto, acta_id, acta_numero, folio,
             acta_tipo, libro_codigo, libro_nombre, anio, grado_numero, grado_nombre, nivel_nombre, numero_orden,
             situacion_final, fecha_registro, normalizada, procesadoconia)
as
SELECT e.id      AS estudiante_id,
       e.dni,
       e.nombres,
       e.apellidopaterno,
       e.apellidomaterno,
       e.nombrecompleto,
       af.id     AS acta_id,
       af.numero AS acta_numero,
       af.folio,
       af.tipo   AS acta_tipo,
       l.codigo  AS libro_codigo,
       l.nombre  AS libro_nombre,
       al.anio,
       g.numero  AS grado_numero,
       g.nombre  AS grado_nombre,
       n.nombre  AS nivel_nombre,
       ae.numero_orden,
       ae.situacion_final,
       ae.fecha_registro,
       af.normalizada,
       af.procesadoconia
FROM actaestudiante ae
         JOIN actafisica af ON ae.acta_id = af.id
         JOIN estudiante e ON ae.estudiante_id = e.id
         JOIN aniolectivo al ON af.aniolectivo_id = al.id
         JOIN grado g ON af.grado_id = g.id
         LEFT JOIN niveleducativo n ON g.nivel_id = n.id
         LEFT JOIN libro l ON af.libro_id = l.id
ORDER BY e.nombrecompleto, al.anio, g.numero;

alter table v_actas_estudiante
    owner to postgres;

