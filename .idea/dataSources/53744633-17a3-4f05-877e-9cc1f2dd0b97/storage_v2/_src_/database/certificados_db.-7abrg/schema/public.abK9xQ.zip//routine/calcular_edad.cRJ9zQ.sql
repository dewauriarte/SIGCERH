create function calcular_edad(fecha_nac date) returns integer
    immutable
    language plpgsql
as
$$
BEGIN
    RETURN EXTRACT(YEAR FROM AGE(fecha_nac));
END;
$$;

alter function calcular_edad(date) owner to postgres;

