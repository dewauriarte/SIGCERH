create function obtener_institucion_default() returns uuid
    stable
    language plpgsql
as
$$
DECLARE
    inst_id UUID;
BEGIN
    -- Retorna la Ãºnica instituciÃ³n activa
    SELECT id INTO inst_id
    FROM ConfiguracionInstitucion
    WHERE activo = true
    LIMIT 1;
    
    IF inst_id IS NULL THEN
        RAISE EXCEPTION 'No hay ninguna instituciÃ³n configurada. Debe crear una en ConfiguracionInstitucion';
    END IF;
    
    RETURN inst_id;
END;
$$;

alter function obtener_institucion_default() owner to postgres;

