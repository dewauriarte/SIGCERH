create view v_notas_estudiante
            (estudiante_id, dni, nombrecompleto, anio, grado_numero, grado_nombre, area_codigo, area_nombre, area_orden,
             nota, nota_literal, es_exonerado, acta_numero, folio, libro_codigo, situacion_final)
as
SELECT e.id      AS estudiante_id,
       e.dni,
       e.nombrecompleto,
       al.anio,
       g.numero  AS grado_numero,
       g.nombre  AS grado_nombre,
       ac.codigo AS area_codigo,
       ac.nombre AS area_nombre,
       ac.orden  AS area_orden,
       an.nota,
       an.nota_literal,
       an.es_exonerado,
       af.numero AS acta_numero,
       af.folio,
       l.codigo  AS libro_codigo,
       ae.situacion_final
FROM actanota an
         JOIN actaestudiante ae ON an.acta_estudiante_id = ae.id
         JOIN estudiante e ON ae.estudiante_id = e.id
         JOIN actafisica af ON ae.acta_id = af.id
         JOIN aniolectivo al ON af.aniolectivo_id = al.id
         JOIN grado g ON af.grado_id = g.id
         JOIN areacurricular ac ON an.area_id = ac.id
         LEFT JOIN libro l ON af.libro_id = l.id
ORDER BY e.nombrecompleto, al.anio, g.numero, ac.orden;

alter table v_notas_estudiante
    owner to postgres;

