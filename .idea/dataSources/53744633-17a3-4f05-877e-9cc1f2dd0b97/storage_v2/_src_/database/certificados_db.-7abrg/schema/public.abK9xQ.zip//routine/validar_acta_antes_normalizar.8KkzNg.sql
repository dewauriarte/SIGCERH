create function validar_acta_antes_normalizar() returns trigger
    language plpgsql
as
$$
BEGIN
    IF NEW.normalizada = true AND OLD.normalizada = false THEN
        -- Verificar que esté procesada con OCR
        IF NEW.procesadoconia = false THEN
            RAISE EXCEPTION 'El acta debe estar procesada con OCR antes de normalizar';
        END IF;

        -- Verificar que tenga JSON
        IF NEW.datosextraidosjson IS NULL THEN
            RAISE EXCEPTION 'El acta no tiene datos JSON para normalizar';
        END IF;
    END IF;

    RETURN NEW;
END;
$$;

alter function validar_acta_antes_normalizar() owner to postgres;

