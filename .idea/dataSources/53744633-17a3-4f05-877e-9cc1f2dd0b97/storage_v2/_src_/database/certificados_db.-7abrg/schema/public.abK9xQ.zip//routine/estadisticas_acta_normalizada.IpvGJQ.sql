create function estadisticas_acta_normalizada(p_acta_id uuid)
    returns TABLE(total_estudiantes integer, total_notas integer, notas_por_estudiante numeric, areas_registradas integer, fecha_normalizacion timestamp with time zone)
    language plpgsql
as
$$
BEGIN
    RETURN QUERY
    SELECT
        COUNT(DISTINCT ae.id)::INTEGER AS total_estudiantes,
        COUNT(an.id)::INTEGER AS total_notas,
        CASE
            WHEN COUNT(DISTINCT ae.id) > 0
            THEN ROUND(COUNT(an.id)::NUMERIC / COUNT(DISTINCT ae.id), 2)
            ELSE 0
        END AS notas_por_estudiante,
        COUNT(DISTINCT an.area_id)::INTEGER AS areas_registradas,
        af.fecha_normalizacion
    FROM actafisica af
    LEFT JOIN actaestudiante ae ON af.id = ae.acta_id
    LEFT JOIN actanota an ON ae.id = an.acta_estudiante_id
    WHERE af.id = p_acta_id
    GROUP BY af.fecha_normalizacion;
END;
$$;

alter function estadisticas_acta_normalizada(uuid) owner to postgres;

