create function obtener_institucion_sesion() returns uuid
    stable
    language plpgsql
as
$$
BEGIN
    RETURN obtener_institucion_default();
END;
$$;

alter function obtener_institucion_sesion() owner to postgres;

