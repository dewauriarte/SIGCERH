create function limpiar_sesiones_expiradas() returns void
    language plpgsql
as
$$
BEGIN
    UPDATE Sesion
    SET activa = false,
        fechaCierre = CURRENT_TIMESTAMP
    WHERE activa = true
      AND fechaExpiracion < CURRENT_TIMESTAMP;
END;
$$;

alter function limpiar_sesiones_expiradas() owner to postgres;

