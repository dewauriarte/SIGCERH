create function bloquear_usuario_intentos() returns trigger
    language plpgsql
as
$$
BEGIN
    IF NEW.intentosFallidos >= 5 AND OLD.intentosFallidos < 5 THEN
        NEW.bloqueado := true;
        NEW.fechaBloqueo := CURRENT_TIMESTAMP;
    END IF;
    
    RETURN NEW;
END;
$$;

alter function bloquear_usuario_intentos() owner to postgres;

