create function actualizar_fecha_modificacion() returns trigger
    language plpgsql
as
$$
BEGIN
    NEW.fechaActualizacion = CURRENT_TIMESTAMP;
    RETURN NEW;
END;
$$;

alter function actualizar_fecha_modificacion() owner to postgres;

