create materialized view mv_estadisticas_certificados as
SELECT institucion_id,
       EXTRACT(year FROM fechaemision)  AS anio,
       EXTRACT(month FROM fechaemision) AS mes,
       estado,
       count(*)                         AS total,
       avg(promediogeneral)             AS promedio_general
FROM certificado c
GROUP BY institucion_id, (EXTRACT(year FROM fechaemision)), (EXTRACT(month FROM fechaemision)), estado;

alter materialized view mv_estadisticas_certificados owner to postgres;

create unique index idx_mv_stats_cert_unique
    on mv_estadisticas_certificados (institucion_id, anio, mes, estado);

create index idx_mv_stats_cert_institucion
    on mv_estadisticas_certificados (institucion_id);

