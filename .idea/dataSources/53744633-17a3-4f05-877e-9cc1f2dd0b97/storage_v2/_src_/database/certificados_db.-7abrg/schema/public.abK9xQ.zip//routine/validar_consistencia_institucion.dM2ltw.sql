create function validar_consistencia_institucion() returns trigger
    language plpgsql
as
$$
DECLARE
    anio_inst_id UUID;
    grado_inst_id UUID;
BEGIN
    -- Validar que aÃ±o lectivo y grado sean de la misma instituciÃ³n
    SELECT institucion_id INTO anio_inst_id FROM AnioLectivo WHERE id = NEW.anioLectivo_id;
    SELECT institucion_id INTO grado_inst_id FROM Grado WHERE id = NEW.grado_id;
    
    IF anio_inst_id != grado_inst_id THEN
        RAISE EXCEPTION 'El aÃ±o lectivo y grado deben pertenecer a la misma instituciÃ³n';
    END IF;
    
    RETURN NEW;
END;
$$;

alter function validar_consistencia_institucion() owner to postgres;

