create function refrescar_estadisticas() returns void
    language plpgsql
as
$$
BEGIN
    REFRESH MATERIALIZED VIEW CONCURRENTLY mv_estadisticas_certificados;
END;
$$;

alter function refrescar_estadisticas() owner to postgres;

